#include <iostream>
#include <string>
using namespace std;

#include "Venda.h"

int main(){
    Venda venda1;

    venda1.set();
    venda1.print();
    
    return 0;
}