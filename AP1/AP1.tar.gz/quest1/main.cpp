#include <iostream>
#include "cilindro.h"

using namespace std;

int main(){
    cilindro c;

    c.setBase(4);
    c.setAltura(8);
    c.setRaio(5);
    c.print();

}